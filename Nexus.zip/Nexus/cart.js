let cartItems = [
    {
        id:1,
        image:"images/Red_Mouse.png",
        title:"Mouse",
        price:35,
        qty:1,
    },
    {
        id:2,
        image:"images/Black_Mouse.png",
        title:"Mouse",
        price:35,
        qty:1,
    },
    {
        id:3,
        image:"images/Blue_Mouse.png",
        title:"Mouse",
        price:35,
        qty:1,
    },
    {
        id:4,
        image:"images/Gray_Mouse.png",
        title:"Mouse",
        price:35,
        qty:1,
    }
]

const itemsContainer = document.querySelector('tbody');


const renderCartItems = ()=>{
    itemsContainer.innerHTML = null

    cartItems.forEach(item => {
        let singleItem = `<tr class="cart_item" id="${item.id}">
                        <td id="del"><i class="fa-solid fa-xmark"></i></td>
                        <td>
                            <div class="item_image">
                                <img src="${item.image}" alt="" srcset="">
                            </div>
                        </td>
                        <td id="title">${item.title}</td>
                        <td id="price">$${item.price}</td>
                        <td id="qty">
                            <input type="number" name="qty" min="1" value=${item.qty} id="qty_input">
                        </td>
                        <td id="total">
                            $${item.price*item.qty}
                        </td>
                         </tr>`;
       itemsContainer.innerHTML += singleItem
    });
}

renderCartItems()


const inputs = document.querySelectorAll('#qty_input');

const delBtns = document.querySelectorAll("#del");

let subTotal = document.querySelector(".sub_total");

let finalTotal = document.querySelector(".final_total");


inputs.forEach(input=>{
    input.addEventListener('change',(e)=>{
        const value = e.target.value;
        const itemID = e.target.parentNode.parentNode;
        let total=0;
        cartItems.forEach(item=>{
            if(item.id===Number(itemID.getAttribute("id"))){
                item.qty=Number(value);
                total = item.price*item.qty;
            }
        })
        itemID.querySelector("#total").innerHTML = `$${total}`
        
    })
})

delBtns.forEach(btn=>{
    btn.addEventListener("click",(e)=>{

        const cartItem = e.target.parentNode.parentNode;

        const itemID = Number(cartItem.getAttribute("id"))

        cartItems = cartItems.filter(item=>item.id!=itemID);
        
        renderCartItems();
        
    })
    
})

