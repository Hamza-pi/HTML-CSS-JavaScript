const currencyDropDown = document.querySelector(".currency_changer");

const humberger = document.querySelector(".humberger");
const links = document.querySelector(".links");
const closeBtn = document.querySelector(".close")
const filterBtn = document.querySelector('.filter_icon')
const filterContainer = document.querySelector('.filter_container')
let currentCurrency = currencyDropDown.querySelector('.currency')
let navLinks = links.querySelectorAll('li a')
let currentPage = "Home"

const currencyList = currencyDropDown?.querySelectorAll('.currency_list');

currencyDropDown?.addEventListener('click',()=>{
    currencyDropDown.querySelector('ul').style.display= currencyDropDown.querySelector('ul').style.display==="block"? "none":"block";
})

 humberger?.addEventListener('click',()=>{
    links.classList.add("show");
 })
 
 closeBtn?.addEventListener("click",()=>{
    links.classList.remove("show")
 })

 filterBtn?.addEventListener("click",()=>{
    filterContainer.style.display=filterContainer.style.display==="none"?"block":"none"
 })

 currencyList?.forEach((list)=>{
   list.addEventListener('click',()=>{
      currentCurrency.innerHTML = list.innerHTML
   })
 })

